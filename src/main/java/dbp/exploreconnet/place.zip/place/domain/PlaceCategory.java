package dbp.exploreconnet.place.domain;

public enum PlaceCategory {
    CAFETERIA,
    RESTAURANT,
    CULTURAL,
    RECREATIONAL,
    EVENT
}