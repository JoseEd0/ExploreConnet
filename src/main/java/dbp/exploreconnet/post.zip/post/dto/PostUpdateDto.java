package dbp.exploreconnet.post.dto;

import lombok.Data;

@Data
public class PostUpdateDto {
    private String imageUrl;
    private String videoUrl;
    private String description;
}
