package dbp.exploreconnet.post.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class PostRequestDto {
    private Long userId;
    private Long placeId;
    private String description;
    private MultipartFile image;
    private MultipartFile video;
}
