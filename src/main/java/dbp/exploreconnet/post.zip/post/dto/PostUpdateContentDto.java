package dbp.exploreconnet.post.dto;


import lombok.Data;

@Data
public class PostUpdateContentDto {
    private Long placeId;

}