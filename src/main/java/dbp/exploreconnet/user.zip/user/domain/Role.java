package dbp.exploreconnet.user.domain;

public enum Role {
    GUEST,
    USER,
    OWNER,
    ADMIN
}